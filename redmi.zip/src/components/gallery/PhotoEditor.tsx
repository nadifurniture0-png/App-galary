'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Photo, TextOverlay, DrawingPath, EditorTool } from './types';
import { backgroundOptions, filterOptions, fontOptions } from './data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';

interface PhotoEditorProps {
  photo: Photo;
  onSave: (dataUrl: string) => void;
  onBack: () => void;
}

export default function PhotoEditor({ photo, onSave, onBack }: PhotoEditorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeTool, setActiveTool] = useState<EditorTool>(null);
  const [textOverlays, setTextOverlays] = useState<TextOverlay[]>([]);
  const [drawingPaths, setDrawingPaths] = useState<DrawingPath[]>([]);
  const [currentPath, setCurrentPath] = useState<DrawingPath | null>(null);
  const [selectedTextId, setSelectedTextId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');
  const [textFontSize, setTextFontSize] = useState(32);
  const [textColor, setTextColor] = useState('#ffffff');
  const [textFont, setTextFont] = useState('sans');
  const [textBold, setTextBold] = useState(false);
  const [textItalic, setTextItalic] = useState(false);
  const [drawColor, setDrawColor] = useState('#ff0000');
  const [drawWidth, setDrawWidth] = useState(4);
  const [selectedBg, setSelectedBg] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState('none');
  const [imageLoaded, setImageLoaded] = useState(false);
  const [canvasSize, setCanvasSize] = useState({ width: 360, height: 640 });
  const imageRef = useRef<HTMLImageElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [isDraggingText, setIsDraggingText] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [showTextInput, setShowTextInput] = useState(false);
  const [textInputPos, setTextInputPos] = useState({ x: 0, y: 0 });

  // Load image
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      imageRef.current = img;
      setImageLoaded(true);
    };
    img.src = photo.src;
  }, [photo.src]);

  // Calculate canvas size
  useEffect(() => {
    if (containerRef.current) {
      const containerWidth = containerRef.current.clientWidth;
      const containerHeight = containerRef.current.clientHeight;
      setCanvasSize({ width: containerWidth, height: containerHeight });
    }
  }, []);

  // Redraw canvas
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !imageRef.current) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = imageRef.current;
    canvas.width = canvasSize.width;
    canvas.height = canvasSize.height;

    // Draw background
    if (selectedBg) {
      const bg = backgroundOptions.find(b => b.id === selectedBg);
      if (bg) {
        if (bg.type === 'solid') {
          ctx.fillStyle = bg.color;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        } else if (bg.type === 'gradient') {
          const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
          const colors = bg.color.match(/#[a-fA-F0-9]{6}/g);
          if (colors && colors.length >= 2) {
            grad.addColorStop(0, colors[0]);
            grad.addColorStop(1, colors[1]);
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
          }
        }
      }
    } else {
      // Draw original image
      const scale = Math.min(canvas.width / img.width, canvas.height / img.height);
      const x = (canvas.width - img.width * scale) / 2;
      const y = (canvas.height - img.height * scale) / 2;
      ctx.drawImage(img, x, y, img.width * scale, img.height * scale);
    }

    // Apply filter
    const filter = filterOptions.find(f => f.id === selectedFilter);
    if (filter && filter.css) {
      ctx.filter = filter.css;
      if (!selectedBg) {
        ctx.drawImage(canvas, 0, 0);
      }
      ctx.filter = 'none';
    }

    // Draw paths
    const allPaths = currentPath ? [...drawingPaths, currentPath] : drawingPaths;
    allPaths.forEach(path => {
      if (path.points.length < 2) return;
      ctx.beginPath();
      ctx.moveTo(path.points[0].x, path.points[0].y);
      for (let i = 1; i < path.points.length; i++) {
        ctx.lineTo(path.points[i].x, path.points[i].y);
      }
      ctx.strokeStyle = path.tool === 'eraser' ? 'rgba(0,0,0,0)' : path.color;
      ctx.lineWidth = path.width;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      if (path.tool === 'eraser') {
        ctx.globalCompositeOperation = 'destination-out';
      }
      ctx.stroke();
      ctx.globalCompositeOperation = 'source-over';
    });

    // Draw text overlays
    textOverlays.forEach(overlay => {
      const fontStr = `${overlay.italic ? 'italic ' : ''}${overlay.bold ? 'bold ' : ''}${overlay.fontSize}px ${fontOptions.find(f => f.id === overlay.fontFamily)?.family || 'sans-serif'}`;
      ctx.font = fontStr;
      ctx.fillStyle = overlay.color;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      // Text shadow for readability
      ctx.shadowColor = 'rgba(0,0,0,0.7)';
      ctx.shadowBlur = 4;
      ctx.shadowOffsetX = 1;
      ctx.shadowOffsetY = 1;
      ctx.fillText(overlay.text, overlay.x, overlay.y);
      ctx.shadowColor = 'transparent';

      // Highlight selected text
      if (selectedTextId === overlay.id) {
        const metrics = ctx.measureText(overlay.text);
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 3]);
        ctx.strokeRect(
          overlay.x - metrics.width / 2 - 6,
          overlay.y - overlay.fontSize / 2 - 4,
          metrics.width + 12,
          overlay.fontSize + 8
        );
        ctx.setLineDash([]);
      }
    });
  }, [canvasSize, textOverlays, drawingPaths, currentPath, selectedBg, selectedFilter, selectedTextId]);

  useEffect(() => {
    if (imageLoaded) {
      redrawCanvas();
    }
  }, [imageLoaded, redrawCanvas]);

  // Handle canvas mouse/touch events
  const getCanvasPos = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    let clientX: number, clientY: number;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  };

  const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
    const pos = getCanvasPos(e);

    if (activeTool === 'text') {
      // Check if clicking on existing text
      const clickedText = textOverlays.find(t => {
        const canvas = canvasRef.current;
        if (!canvas) return false;
        const ctx = canvas.getContext('2d');
        if (!ctx) return false;
        const fontStr = `${t.italic ? 'italic ' : ''}${t.bold ? 'bold ' : ''}${t.fontSize}px sans-serif`;
        ctx.font = fontStr;
        const metrics = ctx.measureText(t.text);
        return (
          pos.x >= t.x - metrics.width / 2 - 6 &&
          pos.x <= t.x + metrics.width / 2 + 6 &&
          pos.y >= t.y - t.fontSize / 2 - 4 &&
          pos.y <= t.y + t.fontSize / 2 + 4
        );
      });

      if (clickedText) {
        setSelectedTextId(clickedText.id);
        setIsDraggingText(true);
        setDragOffset({ x: pos.x - clickedText.x, y: pos.y - clickedText.y });
        setEditingText(clickedText.text);
      } else {
        // Add new text
        setSelectedTextId(null);
        setTextInputPos(pos);
        setShowTextInput(true);
        setEditingText('');
      }
    } else if (activeTool === 'draw') {
      setIsDrawing(true);
      const newPath: DrawingPath = {
        id: Date.now().toString(),
        points: [pos],
        color: drawColor,
        width: drawWidth,
        tool: 'pen',
      };
      setCurrentPath(newPath);
    }
  };

  const handlePointerMove = (e: React.MouseEvent | React.TouchEvent) => {
    const pos = getCanvasPos(e);

    if (isDraggingText && selectedTextId) {
      setTextOverlays(prev =>
        prev.map(t =>
          t.id === selectedTextId
            ? { ...t, x: pos.x - dragOffset.x, y: pos.y - dragOffset.y }
            : t
        )
      );
    } else if (isDrawing && currentPath) {
      setCurrentPath(prev =>
        prev ? { ...prev, points: [...prev.points, pos] } : null
      );
    }
  };

  const handlePointerUp = () => {
    if (isDraggingText) {
      setIsDraggingText(false);
    }
    if (isDrawing && currentPath) {
      setDrawingPaths(prev => [...prev, currentPath]);
      setCurrentPath(null);
      setIsDrawing(false);
    }
  };

  const addTextOverlay = () => {
    if (!editingText.trim()) return;
    const newText: TextOverlay = {
      id: Date.now().toString(),
      text: editingText,
      x: textInputPos.x || canvasSize.width / 2,
      y: textInputPos.y || canvasSize.height / 2,
      fontSize: textFontSize,
      color: textColor,
      fontFamily: textFont,
      bold: textBold,
      italic: textItalic,
    };
    setTextOverlays(prev => [...prev, newText]);
    setShowTextInput(false);
    setEditingText('');
    setSelectedTextId(newText.id);
  };

  const updateSelectedText = () => {
    if (!selectedTextId || !editingText.trim()) return;
    setTextOverlays(prev =>
      prev.map(t =>
        t.id === selectedTextId
          ? {
              ...t,
              text: editingText,
              fontSize: textFontSize,
              color: textColor,
              fontFamily: textFont,
              bold: textBold,
              italic: textItalic,
            }
          : t
      )
    );
  };

  const deleteSelectedText = () => {
    if (!selectedTextId) return;
    setTextOverlays(prev => prev.filter(t => t.id !== selectedTextId));
    setSelectedTextId(null);
    setEditingText('');
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    onSave(dataUrl);
  };

  const handleUndo = () => {
    if (drawingPaths.length > 0) {
      setDrawingPaths(prev => prev.slice(0, -1));
    } else if (textOverlays.length > 0) {
      setTextOverlays(prev => prev.slice(0, -1));
    }
  };

  return (
    <div className="flex flex-col h-full bg-black">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-zinc-900/95 backdrop-blur-sm border-b border-zinc-800">
        <Button variant="ghost" size="sm" onClick={onBack} className="text-white hover:bg-zinc-700">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
          Back
        </Button>
        <span className="text-white font-medium text-sm">Edit Photo</span>
        <div className="flex gap-1">
          <Button variant="ghost" size="sm" onClick={handleUndo} className="text-white hover:bg-zinc-700">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7v6h6M3 13a9 9 0 1 0 3-7.7L3 7"/></svg>
          </Button>
          <Button variant="ghost" size="sm" onClick={handleSave} className="text-amber-400 hover:bg-zinc-700 font-semibold">
            Save
          </Button>
        </div>
      </div>

      {/* Canvas Area */}
      <div ref={containerRef} className="flex-1 relative overflow-hidden">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full"
          onMouseDown={handlePointerDown}
          onMouseMove={handlePointerMove}
          onMouseUp={handlePointerUp}
          onMouseLeave={handlePointerUp}
          onTouchStart={handlePointerDown}
          onTouchMove={handlePointerMove}
          onTouchEnd={handlePointerUp}
          style={{ touchAction: 'none' }}
        />

        {/* Text Input Overlay */}
        {showTextInput && (
          <div
            className="absolute z-10 flex flex-col gap-1 bg-zinc-900/95 rounded-lg p-2 shadow-xl border border-zinc-700"
            style={{ left: Math.min(textInputPos.x, canvasSize.width - 200), top: Math.min(textInputPos.y, canvasSize.height - 100) }}
          >
            <Input
              value={editingText}
              onChange={(e) => setEditingText(e.target.value)}
              placeholder="Type text..."
              className="bg-zinc-800 text-white border-zinc-600 text-sm h-8"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter') addTextOverlay();
                if (e.key === 'Escape') setShowTextInput(false);
              }}
            />
            <div className="flex gap-1">
              <Button size="sm" onClick={addTextOverlay} className="h-6 text-xs bg-amber-500 hover:bg-amber-600 text-black">
                Add
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setShowTextInput(false)} className="h-6 text-xs text-zinc-400">
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Tool Panels */}
      {activeTool === 'text' && (
        <div className="bg-zinc-900/95 backdrop-blur-sm border-t border-zinc-800 p-3 space-y-3">
          <div className="flex items-center gap-2">
            <Input
              value={editingText}
              onChange={(e) => setEditingText(e.target.value)}
              placeholder="Type here..."
              className="bg-zinc-800 text-white border-zinc-600 text-sm h-9 flex-1"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  if (selectedTextId) updateSelectedText();
                  else {
                    setTextInputPos({ x: canvasSize.width / 2, y: canvasSize.height / 2 });
                    addTextOverlay();
                  }
                }
              }}
            />
            {selectedTextId && (
              <>
                <Button size="sm" onClick={updateSelectedText} className="h-9 bg-amber-500 hover:bg-amber-600 text-black text-xs">
                  Update
                </Button>
                <Button size="sm" variant="ghost" onClick={deleteSelectedText} className="h-9 text-red-400 text-xs">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                </Button>
              </>
            )}
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <label className="text-xs text-zinc-400">Size</label>
              <input
                type="range"
                min="12"
                max="72"
                value={textFontSize}
                onChange={(e) => setTextFontSize(Number(e.target.value))}
                className="w-20"
              />
              <span className="text-xs text-zinc-400 w-6">{textFontSize}</span>
            </div>
            <div className="flex gap-1">
              <Button
                size="sm"
                variant={textBold ? 'default' : 'ghost'}
                onClick={() => setTextBold(!textBold)}
                className={`h-7 w-7 p-0 text-xs font-bold ${textBold ? 'bg-amber-500 text-black' : 'text-zinc-400'}`}
              >
                B
              </Button>
              <Button
                size="sm"
                variant={textItalic ? 'default' : 'ghost'}
                onClick={() => setTextItalic(!textItalic)}
                className={`h-7 w-7 p-0 text-xs italic ${textItalic ? 'bg-amber-500 text-black' : 'text-zinc-400'}`}
              >
                I
              </Button>
            </div>
            <select
              value={textFont}
              onChange={(e) => setTextFont(e.target.value)}
              className="bg-zinc-800 text-white text-xs rounded px-2 py-1 border border-zinc-600"
            >
              {fontOptions.map(f => (
                <option key={f.id} value={f.id}>{f.name}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-2">
            <label className="text-xs text-zinc-400">Color</label>
            <div className="flex gap-1.5 flex-wrap">
              {['#ffffff', '#000000', '#ef4444', '#f59e0b', '#22c55e', '#3b82f6', '#a855f7', '#ec4899'].map(c => (
                <button
                  key={c}
                  className={`w-7 h-7 rounded-full border-2 ${textColor === c ? 'border-amber-400 scale-110' : 'border-zinc-600'}`}
                  style={{ backgroundColor: c }}
                  onClick={() => setTextColor(c)}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTool === 'draw' && (
        <div className="bg-zinc-900/95 backdrop-blur-sm border-t border-zinc-800 p-3 space-y-3">
          <div className="flex items-center gap-2">
            <label className="text-xs text-zinc-400">Color</label>
            <div className="flex gap-1.5 flex-wrap">
              {['#ffffff', '#ef4444', '#f59e0b', '#22c55e', '#3b82f6', '#a855f7', '#ec4899', '#000000'].map(c => (
                <button
                  key={c}
                  className={`w-7 h-7 rounded-full border-2 ${drawColor === c ? 'border-amber-400 scale-110' : 'border-zinc-600'}`}
                  style={{ backgroundColor: c }}
                  onClick={() => setDrawColor(c)}
                />
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <label className="text-xs text-zinc-400">Size</label>
            <input
              type="range"
              min="1"
              max="20"
              value={drawWidth}
              onChange={(e) => setDrawWidth(Number(e.target.value))}
              className="w-32"
            />
            <span className="text-xs text-zinc-400 w-4">{drawWidth}</span>
            <div className="flex-1" />
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setDrawingPaths([]);
                setCurrentPath(null);
              }}
              className="text-red-400 text-xs"
            >
              Clear All
            </Button>
          </div>
        </div>
      )}

      {activeTool === 'background' && (
        <div className="bg-zinc-900/95 backdrop-blur-sm border-t border-zinc-800 p-3">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {backgroundOptions.map(bg => (
              <button
                key={bg.id}
                className={`flex-shrink-0 w-14 h-14 rounded-lg border-2 ${selectedBg === bg.id ? 'border-amber-400 scale-105' : 'border-zinc-600'} transition-all`}
                style={{ background: bg.type === 'solid' ? bg.color : bg.color }}
                onClick={() => setSelectedBg(selectedBg === bg.id ? null : bg.id)}
                title={bg.name}
              />
            ))}
            <button
              className={`flex-shrink-0 w-14 h-14 rounded-lg border-2 ${!selectedBg ? 'border-amber-400' : 'border-zinc-600'} bg-zinc-700 flex items-center justify-center text-xs text-zinc-400`}
              onClick={() => setSelectedBg(null)}
            >
              None
            </button>
          </div>
        </div>
      )}

      {activeTool === 'filter' && (
        <div className="bg-zinc-900/95 backdrop-blur-sm border-t border-zinc-800 p-3">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {filterOptions.map(filter => (
              <button
                key={filter.id}
                className={`flex-shrink-0 flex flex-col items-center gap-1 px-2 py-1.5 rounded-lg ${selectedFilter === filter.id ? 'bg-amber-500/20 border border-amber-400' : 'bg-zinc-800 border border-zinc-700'}`}
                onClick={() => setSelectedFilter(filter.id)}
              >
                <div
                  className="w-12 h-12 rounded bg-zinc-600"
                  style={{ filter: filter.css || 'none' }}
                />
                <span className="text-[10px] text-zinc-300">{filter.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Bottom Toolbar */}
      <div className="bg-zinc-900/95 backdrop-blur-sm border-t border-zinc-800 px-2 py-2">
        <div className="flex justify-around items-center">
          {[
            { id: 'text' as EditorTool, label: 'Text', icon: (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 7V4h16v3M9 20h6M12 4v16"/></svg>
            )},
            { id: 'draw' as EditorTool, label: 'Draw', icon: (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/></svg>
            )},
            { id: 'background' as EditorTool, label: 'BG', icon: (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 3l18 18M3 9l12 12M3 15l6 6M9 3l12 12M15 3l6 6"/></svg>
            )},
            { id: 'filter' as EditorTool, label: 'Filter', icon: (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
            )},
          ].map(tool => (
            <button
              key={tool.id}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg transition-all ${
                activeTool === tool.id
                  ? 'text-amber-400 bg-amber-500/10'
                  : 'text-zinc-400 hover:text-white'
              }`}
              onClick={() => setActiveTool(activeTool === tool.id ? null : tool.id)}
            >
              {tool.icon}
              <span className="text-[10px]">{tool.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
