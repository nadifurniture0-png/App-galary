'use client';

import React, { useState, useCallback } from 'react';
import { ViewMode, Photo, Album } from './types';
import { samplePhotos, sampleAlbums } from './data';
import PhotoViewer from './PhotoViewer';
import PhotoEditor from './PhotoEditor';
import AlbumView from './AlbumView';
import { toast } from 'sonner';

export default function GalleryApp() {
  const [viewMode, setViewMode] = useState<ViewMode>('gallery');
  const [photos, setPhotos] = useState<Photo[]>(samplePhotos);
  const [albums, setAlbums] = useState<Album[]>(sampleAlbums);
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);
  const [currentAlbumId, setCurrentAlbumId] = useState<string | null>(null);
  const [viewStyle, setViewStyle] = useState<'grid' | 'list'>('grid');
  const [tab, setTab] = useState<'photos' | 'albums'>('photos');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter photos based on current album and search
  const displayedPhotos = photos.filter(p => {
    const matchesAlbum = currentAlbumId ? p.albumId === currentAlbumId : true;
    const matchesSearch = searchQuery
      ? p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.albumId.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    return matchesAlbum && matchesSearch;
  });

  const handlePhotoClick = (photo: Photo, index: number) => {
    setSelectedPhoto(photo);
    setSelectedPhotoIndex(index);
    setViewMode('viewer');
  };

  const handleNextPhoto = useCallback(() => {
    if (selectedPhotoIndex < displayedPhotos.length - 1) {
      const nextIndex = selectedPhotoIndex + 1;
      setSelectedPhoto(displayedPhotos[nextIndex]);
      setSelectedPhotoIndex(nextIndex);
    }
  }, [selectedPhotoIndex, displayedPhotos]);

  const handlePrevPhoto = useCallback(() => {
    if (selectedPhotoIndex > 0) {
      const prevIndex = selectedPhotoIndex - 1;
      setSelectedPhoto(displayedPhotos[prevIndex]);
      setSelectedPhotoIndex(prevIndex);
    }
  }, [selectedPhotoIndex, displayedPhotos]);

  const handleEdit = () => {
    setViewMode('editor');
  };

  const handleSaveEdit = (dataUrl: string) => {
    if (selectedPhoto) {
      // Create a new photo entry for the edited version
      const editedPhoto: Photo = {
        ...selectedPhoto,
        id: `edited-${Date.now()}`,
        src: dataUrl,
        thumbnail: dataUrl,
        name: `${selectedPhoto.name} (Edited)`,
        date: new Date().toISOString().split('T')[0],
        albumId: selectedPhoto.albumId,
      };
      setPhotos(prev => [editedPhoto, ...prev]);
      toast.success('Photo saved!', {
        description: 'Edited photo added to gallery',
      });
    }
    setViewMode('viewer');
  };

  const handleAlbumClick = (albumId: string) => {
    setCurrentAlbumId(albumId);
    setTab('photos');
  };

  const handleCreateAlbum = (name: string) => {
    const newAlbum: Album = {
      id: name.toLowerCase().replace(/\s+/g, '-'),
      name,
      cover: `https://picsum.photos/seed/${name}/300/300`,
      count: 0,
      date: new Date().toISOString().split('T')[0],
    };
    setAlbums(prev => [...prev, newAlbum]);
    toast.success('Album created!', {
      description: `"${name}" album has been created`,
    });
  };

  const handleUploadPhoto = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = true;
    input.onchange = (e) => {
      const files = (e.target as HTMLInputElement).files;
      if (files) {
        Array.from(files).forEach(file => {
          const reader = new FileReader();
          reader.onload = (ev) => {
            const src = ev.target?.result as string;
            const newPhoto: Photo = {
              id: `upload-${Date.now()}-${Math.random().toString(36).slice(2)}`,
              src,
              thumbnail: src,
              name: file.name.replace(/\.[^.]+$/, ''),
              date: new Date().toISOString().split('T')[0],
              albumId: currentAlbumId || 'uncategorized',
              width: 800,
              height: 600,
            };
            setPhotos(prev => [newPhoto, ...prev]);
          };
          reader.readAsDataURL(file);
        });
        toast.success('Photos uploaded!', {
          description: `${files.length} photo(s) added to gallery`,
        });
      }
    };
    input.click();
  };

  // Date-based grouping
  const groupedPhotos = displayedPhotos.reduce((acc, photo) => {
    if (!acc[photo.date]) acc[photo.date] = [];
    acc[photo.date].push(photo);
    return acc;
  }, {} as Record<string, Photo[]>);

  const sortedDates = Object.keys(groupedPhotos).sort((a, b) => b.localeCompare(a));

  // Render based on view mode
  if (viewMode === 'editor' && selectedPhoto) {
    return (
      <PhotoEditor
        photo={selectedPhoto}
        onSave={handleSaveEdit}
        onBack={() => setViewMode('viewer')}
      />
    );
  }

  if (viewMode === 'viewer' && selectedPhoto) {
    return (
      <PhotoViewer
        photo={selectedPhoto}
        onBack={() => setViewMode('gallery')}
        onEdit={handleEdit}
        onNext={selectedPhotoIndex < displayedPhotos.length - 1 ? handleNextPhoto : undefined}
        onPrev={selectedPhotoIndex > 0 ? handlePrevPhoto : undefined}
      />
    );
  }

  if (viewMode === 'album') {
    return (
      <AlbumView
        albums={albums}
        onAlbumClick={handleAlbumClick}
        onBack={() => { setViewMode('gallery'); setCurrentAlbumId(null); }}
        onCreateAlbum={handleCreateAlbum}
      />
    );
  }

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a]">
      {/* Header */}
      <div className="px-4 pt-3 pb-2 bg-zinc-900/95 backdrop-blur-sm border-b border-zinc-800">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="text-white font-bold text-xl">
              {currentAlbumId
                ? albums.find(a => a.id === currentAlbumId)?.name || 'Gallery'
                : 'My Gallery'}
            </h1>
            <p className="text-zinc-500 text-xs">
              {displayedPhotos.length} photos
              {currentAlbumId && (
                <button
                  onClick={() => setCurrentAlbumId(null)}
                  className="ml-2 text-amber-400 hover:text-amber-300"
                >
                  All Photos →
                </button>
              )}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleUploadPhoto}
              className="p-2 rounded-full bg-amber-500 hover:bg-amber-600 transition-colors"
              title="Upload photos"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-black" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14"/></svg>
            </button>
            <button
              onClick={() => setViewStyle(viewStyle === 'grid' ? 'list' : 'grid')}
              className="p-2 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 transition-colors"
            >
              {viewStyle === 'grid' ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>
              )}
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-2">
          <svg xmlns="http://www.w3.org/2000/svg" className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search photos..."
            className="w-full bg-zinc-800 text-white rounded-xl pl-9 pr-4 py-2.5 text-sm border border-zinc-700 focus:border-amber-400 focus:outline-none placeholder:text-zinc-500"
          />
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-zinc-800 rounded-lg p-0.5">
          <button
            onClick={() => setTab('photos')}
            className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${
              tab === 'photos'
                ? 'bg-amber-500 text-black'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Photos
          </button>
          <button
            onClick={() => { setTab('albums'); setViewMode('album'); }}
            className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${
              tab === 'albums'
                ? 'bg-amber-500 text-black'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Albums
          </button>
        </div>
      </div>

      {/* Gallery Grid */}
      <div className="flex-1 overflow-y-auto scrollbar-hide">
        {sortedDates.map(date => (
          <div key={date} className="mb-1">
            {/* Date Header */}
            <div className="sticky top-0 z-5 bg-[#0a0a0a]/90 backdrop-blur-sm px-4 py-1.5">
              <span className="text-zinc-400 text-xs font-medium">
                {new Date(date).toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </span>
            </div>

            {/* Photo Grid */}
            {viewStyle === 'grid' ? (
              <div className="grid grid-cols-3 gap-0.5 px-0.5">
                {groupedPhotos[date].map((photo, index) => (
                  <button
                    key={photo.id}
                    onClick={() => handlePhotoClick(photo, displayedPhotos.indexOf(photo))}
                    className="relative aspect-square overflow-hidden group"
                  >
                    <img
                      src={photo.thumbnail}
                      alt={photo.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                  </button>
                ))}
              </div>
            ) : (
              <div className="space-y-2 px-3">
                {groupedPhotos[date].map((photo, index) => (
                  <button
                    key={photo.id}
                    onClick={() => handlePhotoClick(photo, displayedPhotos.indexOf(photo))}
                    className="flex items-center gap-3 bg-zinc-900 rounded-xl p-2 hover:bg-zinc-800 transition-colors w-full"
                  >
                    <img
                      src={photo.thumbnail}
                      alt={photo.name}
                      className="w-16 h-16 rounded-lg object-cover"
                      loading="lazy"
                    />
                    <div className="text-left flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">{photo.name}</p>
                      <p className="text-zinc-500 text-xs">{photo.albumId} • {photo.width}x{photo.height}</p>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-zinc-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 5l7 7-7 7"/></svg>
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {displayedPhotos.length === 0 && (
          <div className="flex flex-col items-center justify-center h-64 text-zinc-500">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4 text-zinc-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
            <p className="text-lg font-medium">No photos found</p>
            <p className="text-sm mt-1">
              {searchQuery ? 'Try a different search' : 'Upload photos to get started'}
            </p>
            <button
              onClick={handleUploadPhoto}
              className="mt-4 bg-amber-500 text-black font-semibold px-6 py-2 rounded-xl hover:bg-amber-600 transition-colors"
            >
              Upload Photos
            </button>
          </div>
        )}
      </div>

      {/* Bottom Quick Actions */}
      <div className="bg-zinc-900/95 backdrop-blur-sm border-t border-zinc-800 px-4 py-2">
        <div className="flex justify-around">
          <button
            onClick={() => { setCurrentAlbumId(null); setTab('photos'); }}
            className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg ${!currentAlbumId && tab === 'photos' ? 'text-amber-400' : 'text-zinc-500'} hover:text-white transition-colors`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
            <span className="text-[10px]">All</span>
          </button>
          <button
            onClick={() => setViewMode('album')}
            className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg ${viewMode === 'album' ? 'text-amber-400' : 'text-zinc-500'} hover:text-white transition-colors`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
            <span className="text-[10px]">Albums</span>
          </button>
          <button
            onClick={handleUploadPhoto}
            className="flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg text-zinc-500 hover:text-white transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
            <span className="text-[10px]">Upload</span>
          </button>
          <button
            onClick={() => {
              if (photos.length > 0) {
                const randomIndex = Math.floor(Math.random() * photos.length);
                handlePhotoClick(photos[randomIndex], randomIndex);
              }
            }}
            className="flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg text-zinc-500 hover:text-white transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/><path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <span className="text-[10px]">Slideshow</span>
          </button>
        </div>
      </div>
    </div>
  );
}
