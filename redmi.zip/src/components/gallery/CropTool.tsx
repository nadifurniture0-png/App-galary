'use client'

import { useGalleryStore, type CropRatio } from '@/lib/gallery-store'
import { useState, useRef, useMemo, useCallback } from 'react'
import { Check } from 'lucide-react'
import { toast } from 'sonner'

interface CropToolProps {
  canvasWidth: number
  canvasHeight: number
}

const ratios: { id: CropRatio; label: string }[] = [
  { id: 'free', label: 'Free' },
  { id: '1:1', label: '1:1' },
  { id: '4:3', label: '4:3' },
  { id: '16:9', label: '16:9' },
]

function computeDefaultRect(cropRatio: CropRatio, canvasWidth: number, canvasHeight: number) {
  let w = canvasWidth
  let h = canvasHeight

  if (cropRatio === '1:1') {
    const size = Math.min(w, h)
    w = size
    h = size
  } else if (cropRatio === '4:3') {
    h = (w * 3) / 4
    if (h > canvasHeight) {
      h = canvasHeight
      w = (h * 4) / 3
    }
  } else if (cropRatio === '16:9') {
    h = (w * 9) / 16
    if (h > canvasHeight) {
      h = canvasHeight
      w = (h * 16) / 9
    }
  }

  return {
    x: Math.round((canvasWidth - w) / 2),
    y: Math.round((canvasHeight - h) / 2),
    w: Math.round(w),
    h: Math.round(h),
  }
}

export function CropTool({ canvasWidth, canvasHeight }: CropToolProps) {
  const { cropRatio, setCropRatio } = useGalleryStore()
  const defaultRect = useMemo(() => computeDefaultRect(cropRatio, canvasWidth, canvasHeight), [cropRatio, canvasWidth, canvasHeight])
  const [cropRect, setCropRect] = useState(defaultRect)
  const [manualRect, setManualRect] = useState<typeof defaultRect | null>(null)
  const overlayRef = useRef<HTMLDivElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [dragType, setDragType] = useState<'move' | 'resize'>('move')
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [initialRect, setInitialRect] = useState(cropRect)

  const activeRect = manualRect ?? defaultRect

  const handleRatioChange = (ratio: CropRatio) => {
    setCropRatio(ratio)
    setManualRect(null)
  }

  const handleTouchStart = useCallback(
    (e: React.TouchEvent, type: 'move' | 'resize') => {
      e.preventDefault()
      e.stopPropagation()
      const touch = e.touches[0]
      setIsDragging(true)
      setDragType(type)
      setDragStart({ x: touch.clientX, y: touch.clientY })
      setInitialRect({ ...activeRect })
    },
    [activeRect]
  )

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (!isDragging) return
      e.preventDefault()
      const touch = e.touches[0]
      const dx = touch.clientX - dragStart.x
      const dy = touch.clientY - dragStart.y

      if (dragType === 'move') {
        const newRect = {
          ...activeRect,
          x: Math.max(0, Math.min(canvasWidth - activeRect.w, initialRect.x + dx)),
          y: Math.max(0, Math.min(canvasHeight - activeRect.h, initialRect.y + dy)),
        }
        setManualRect(newRect)
      } else {
        const newW = Math.max(40, Math.min(canvasWidth - activeRect.x, initialRect.w + dx))
        const newH = cropRatio === '1:1' ? newW : cropRatio === '4:3' ? (newW * 3) / 4 : cropRatio === '16:9' ? (newW * 9) / 16 : Math.max(40, initialRect.h + dy)
        const newRect = {
          ...activeRect,
          w: Math.round(newW),
          h: Math.round(newH),
        }
        setManualRect(newRect)
      }
    },
    [isDragging, dragType, dragStart, initialRect, activeRect, canvasWidth, canvasHeight, cropRatio]
  )

  const handleTouchEnd = useCallback(() => {
    setIsDragging(false)
  }, [])

  const handleApply = () => {
    toast.success('Crop applied! Use Save to download the cropped image.')
  }

  return (
    <div className="px-4 py-3 space-y-3">
      {/* Ratio Buttons */}
      <div className="flex items-center gap-2">
        {ratios.map((ratio) => (
          <button
            key={ratio.id}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              cropRatio === ratio.id
                ? 'bg-amber-400/20 text-amber-400'
                : 'bg-white/5 text-white/50'
            }`}
            onClick={() => handleRatioChange(ratio.id)}
          >
            {ratio.label}
          </button>
        ))}
        <button
          className="ml-auto px-3 py-1.5 bg-amber-500 rounded-md text-xs font-medium text-black active:scale-95 transition-transform"
          onClick={handleApply}
        >
          <Check className="w-3.5 h-3.5 inline mr-1" />
          Apply
        </button>
      </div>

      {/* Crop Overlay Preview */}
      <div
        ref={overlayRef}
        className="relative bg-white/5 rounded-lg overflow-hidden"
        style={{
          width: '100%',
          aspectRatio: `${canvasWidth}/${canvasHeight}`,
          touchAction: 'none',
        }}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/60" />

        {/* Crop area */}
        <div
          className="absolute border-2 border-amber-400 bg-transparent"
          style={{
            left: `${(activeRect.x / canvasWidth) * 100}%`,
            top: `${(activeRect.y / canvasHeight) * 100}%`,
            width: `${(activeRect.w / canvasWidth) * 100}%`,
            height: `${(activeRect.h / canvasHeight) * 100}%`,
          }}
          onTouchStart={(e) => handleTouchStart(e, 'move')}
        >
          {/* Corner handles */}
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-amber-400 rounded-full"
            onTouchStart={(e) => handleTouchStart(e, 'resize')}
          />
          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-amber-400 rounded-full"
            onTouchStart={(e) => handleTouchStart(e, 'resize')}
          />

          {/* Grid lines */}
          <div className="absolute inset-0">
            <div className="absolute top-1/3 left-0 right-0 border-t border-white/20" />
            <div className="absolute top-2/3 left-0 right-0 border-t border-white/20" />
            <div className="absolute left-1/3 top-0 bottom-0 border-l border-white/20" />
            <div className="absolute left-2/3 top-0 bottom-0 border-l border-white/20" />
          </div>
        </div>

        {/* Size label */}
        <div className="absolute bottom-2 left-2 bg-black/60 rounded px-1.5 py-0.5 text-[9px] text-white/60">
          {activeRect.w} × {activeRect.h}
        </div>
      </div>
    </div>
  )
}
