export interface Photo {
  id: string;
  src: string;
  thumbnail: string;
  name: string;
  date: string;
  albumId: string;
  width: number;
  height: number;
}

export interface Album {
  id: string;
  name: string;
  cover: string;
  count: number;
  date: string;
}

export interface TextOverlay {
  id: string;
  text: string;
  x: number;
  y: number;
  fontSize: number;
  color: string;
  fontFamily: string;
  bold: boolean;
  italic: boolean;
}

export interface DrawingPath {
  id: string;
  points: { x: number; y: number }[];
  color: string;
  width: number;
  tool: 'pen' | 'eraser';
}

export type EditorTool = 'text' | 'draw' | 'background' | 'filter' | 'crop' | null;

export type ViewMode = 'gallery' | 'album' | 'viewer' | 'editor';
