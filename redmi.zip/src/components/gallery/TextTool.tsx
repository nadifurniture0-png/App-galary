'use client'

import { useGalleryStore, type TextObject } from '@/lib/gallery-store'
import { useState } from 'react'
import { Plus, Trash2, Bold, Italic } from 'lucide-react'

const presetColors = [
  '#ffffff',
  '#000000',
  '#f59e0b',
  '#ef4444',
  '#22c55e',
  '#3b82f6',
  '#a855f7',
  '#ec4899',
  '#06b6d4',
  '#f97316',
]

export function TextTool() {
  const { textColor, textSize, textBold, textItalic, addTextObject, textObjects, removeTextObject } =
    useGalleryStore()
  const { setTextColor, setTextSize, setTextBold, setTextItalic } = useGalleryStore()
  const [textInput, setTextInput] = useState('')

  const handleAddText = () => {
    if (!textInput.trim()) return
    const obj: TextObject = {
      id: Date.now().toString(),
      text: textInput.trim(),
      x: 50,
      y: 50,
      fontSize: textSize,
      color: textColor,
      bold: textBold,
      italic: textItalic,
    }
    addTextObject(obj)
    setTextInput('')
  }

  return (
    <div className="px-4 py-3 space-y-3">
      {/* Text Input Row */}
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={textInput}
          onChange={(e) => setTextInput(e.target.value)}
          placeholder="Enter text..."
          className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-amber-400/50"
        />
        <button
          className="w-9 h-9 flex items-center justify-center bg-amber-500 rounded-lg active:scale-95 transition-transform"
          onClick={handleAddText}
          disabled={!textInput.trim()}
          aria-label="Add text"
        >
          <Plus className="w-4 h-4 text-black" />
        </button>
      </div>

      {/* Font Size Slider */}
      <div className="flex items-center gap-3">
        <span className="text-xs text-white/50 w-8">{textSize}</span>
        <input
          type="range"
          min="12"
          max="72"
          value={textSize}
          onChange={(e) => setTextSize(Number(e.target.value))}
          className="flex-1 accent-amber-400 h-1"
        />
        <span className="text-xs text-white/30">Size</span>
      </div>

      {/* Bold / Italic */}
      <div className="flex items-center gap-2">
        <button
          className={`w-9 h-9 flex items-center justify-center rounded-lg transition-colors ${
            textBold ? 'bg-amber-400/20 text-amber-400' : 'bg-white/5 text-white/50'
          }`}
          onClick={() => setTextBold(!textBold)}
          aria-label="Bold"
        >
          <Bold className="w-4 h-4" />
        </button>
        <button
          className={`w-9 h-9 flex items-center justify-center rounded-lg transition-colors ${
            textItalic ? 'bg-amber-400/20 text-amber-400' : 'bg-white/5 text-white/50'
          }`}
          onClick={() => setTextItalic(!textItalic)}
          aria-label="Italic"
        >
          <Italic className="w-4 h-4" />
        </button>
      </div>

      {/* Color Picker */}
      <div className="flex items-center gap-2 flex-wrap">
        {presetColors.map((color) => (
          <button
            key={color}
            className={`w-7 h-7 rounded-full border-2 transition-transform active:scale-90 ${
              textColor === color ? 'border-amber-400 scale-110' : 'border-transparent'
            }`}
            style={{ backgroundColor: color }}
            onClick={() => setTextColor(color)}
            aria-label={`Color ${color}`}
          />
        ))}
        <input
          type="color"
          value={textColor}
          onChange={(e) => setTextColor(e.target.value)}
          className="w-7 h-7 rounded-full cursor-pointer border-0 bg-transparent"
          aria-label="Custom color"
        />
      </div>

      {/* Text Objects List */}
      {textObjects.length > 0 && (
        <div className="space-y-1 max-h-24 overflow-y-auto">
          {textObjects.map((obj) => (
            <div
              key={obj.id}
              className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-1.5"
            >
              <span className="text-xs text-white/70 truncate flex-1">{obj.text}</span>
              <button
                className="w-7 h-7 flex items-center justify-center text-red-400/70 active:scale-90 transition-transform"
                onClick={() => removeTextObject(obj.id)}
                aria-label="Remove text"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
