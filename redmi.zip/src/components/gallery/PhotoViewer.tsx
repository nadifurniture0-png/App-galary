'use client';

import React, { useState, useEffect } from 'react';
import { Photo } from './types';
import { Button } from '@/components/ui/button';

interface PhotoViewerProps {
  photo: Photo;
  onBack: () => void;
  onEdit: () => void;
  onNext?: () => void;
  onPrev?: () => void;
}

export default function PhotoViewer({ photo, onBack, onEdit, onNext, onPrev }: PhotoViewerProps) {
  const [zoom, setZoom] = useState(1);
  const [showInfo, setShowInfo] = useState(false);

  // Keyboard navigation
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' && onNext) onNext();
      if (e.key === 'ArrowLeft' && onPrev) onPrev();
      if (e.key === 'Escape') onBack();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onNext, onPrev, onBack]);

  // Swipe support
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.touches[0].clientX);
  };
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStart === null) return;
    const diff = e.changedTouches[0].clientX - touchStart;
    if (Math.abs(diff) > 50) {
      if (diff < 0 && onNext) onNext();
      if (diff > 0 && onPrev) onPrev();
    }
    setTouchStart(null);
  };

  return (
    <div className="flex flex-col h-full bg-black">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-black/80 backdrop-blur-sm absolute top-0 left-0 right-0 z-10">
        <Button variant="ghost" size="sm" onClick={onBack} className="text-white hover:bg-white/10">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
          Back
        </Button>
        <span className="text-white/70 text-sm">{photo.name}</span>
        <Button variant="ghost" size="sm" onClick={() => setShowInfo(!showInfo)} className="text-white hover:bg-white/10">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
        </Button>
      </div>

      {/* Image */}
      <div
        className="flex-1 flex items-center justify-center overflow-hidden"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        <img
          src={photo.src}
          alt={photo.name}
          className="max-w-full max-h-full object-contain transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
          draggable={false}
        />
      </div>

      {/* Info Panel */}
      {showInfo && (
        <div className="absolute bottom-20 left-3 right-3 bg-zinc-900/95 backdrop-blur-sm rounded-xl p-4 border border-zinc-700 z-20">
          <h3 className="text-white font-semibold mb-2">{photo.name}</h3>
          <div className="space-y-1 text-sm text-zinc-400">
            <p>Date: {photo.date}</p>
            <p>Size: {photo.width} x {photo.height}</p>
            <p>Album: {photo.albumId}</p>
          </div>
        </div>
      )}

      {/* Bottom Controls */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/80 backdrop-blur-sm absolute bottom-0 left-0 right-0 z-10">
        <Button variant="ghost" size="sm" onClick={onPrev} className="text-white hover:bg-white/10" disabled={!onPrev}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 19l-7-7 7-7"/></svg>
        </Button>

        <div className="flex gap-3 items-center">
          <Button variant="ghost" size="sm" onClick={() => setZoom(z => Math.min(z + 0.5, 3))} className="text-white hover:bg-white/10">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35M11 8v6M8 11h6"/></svg>
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setZoom(1)} className="text-white text-xs hover:bg-white/10">
            {Math.round(zoom * 100)}%
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setZoom(z => Math.max(z - 0.5, 0.5))} className="text-white hover:bg-white/10">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35M8 11h6"/></svg>
          </Button>
        </div>

        <Button
          size="sm"
          onClick={onEdit}
          className="bg-amber-500 hover:bg-amber-600 text-black font-semibold px-4"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          Edit
        </Button>

        <Button variant="ghost" size="sm" onClick={onNext} className="text-white hover:bg-white/10" disabled={!onNext}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 5l7 7-7 7"/></svg>
        </Button>
      </div>
    </div>
  );
}
