import { Photo, Album } from './types';

// Sample photos using picsum.photos
const photoSources = [
  { id: '1', seed: 'nature1', w: 800, h: 1200, name: 'Sunset Beach', album: 'nature' },
  { id: '2', seed: 'nature2', w: 800, h: 600, name: 'Mountain Lake', album: 'nature' },
  { id: '3', seed: 'city1', w: 600, h: 800, name: 'City Night', album: 'city' },
  { id: '4', seed: 'city2', w: 800, h: 800, name: 'Urban Street', album: 'city' },
  { id: '5', seed: 'food1', w: 800, h: 800, name: 'Morning Coffee', album: 'food' },
  { id: '6', seed: 'food2', w: 600, h: 800, name: 'Pasta Dish', album: 'food' },
  { id: '7', seed: 'portrait1', w: 600, h: 900, name: 'Portrait', album: 'people' },
  { id: '8', seed: 'portrait2', w: 800, h: 1000, name: 'Friends', album: 'people' },
  { id: '9', seed: 'travel1', w: 900, h: 600, name: 'Temple View', album: 'travel' },
  { id: '10', seed: 'travel2', w: 800, h: 600, name: 'Beach Walk', album: 'travel' },
  { id: '11', seed: 'flower1', w: 800, h: 900, name: 'Red Rose', album: 'nature' },
  { id: '12', seed: 'flower2', w: 700, h: 900, name: 'Sunflower', album: 'nature' },
  { id: '13', seed: 'pet1', w: 800, h: 800, name: 'My Cat', album: 'pets' },
  { id: '14', seed: 'pet2', w: 900, h: 700, name: 'Dog Park', album: 'pets' },
  { id: '15', seed: 'sunset1', w: 1000, h: 600, name: 'Golden Hour', album: 'nature' },
  { id: '16', seed: 'night1', w: 800, h: 600, name: 'Starlit Sky', album: 'nature' },
  { id: '17', seed: 'food3', w: 700, h: 700, name: 'Sushi Plate', album: 'food' },
  { id: '18', seed: 'arch1', w: 600, h: 900, name: 'Old Building', album: 'city' },
  { id: '19', seed: 'forest1', w: 800, h: 1000, name: 'Forest Path', album: 'nature' },
  { id: '20', seed: 'ocean1', w: 900, h: 600, name: 'Ocean Waves', album: 'travel' },
  { id: '21', seed: 'mountain1', w: 1000, h: 700, name: 'Snow Peak', album: 'travel' },
  { id: '22', seed: 'garden1', w: 800, h: 800, name: 'Garden View', album: 'nature' },
  { id: '23', seed: 'bridge1', w: 900, h: 600, name: 'Old Bridge', album: 'city' },
  { id: '24', seed: 'coffee1', w: 700, h: 900, name: 'Latte Art', album: 'food' },
];

export const samplePhotos: Photo[] = photoSources.map((p) => ({
  id: p.id,
  src: `https://picsum.photos/seed/${p.seed}/${p.w}/${p.h}`,
  thumbnail: `https://picsum.photos/seed/${p.seed}/300/300`,
  name: p.name,
  date: '2026-04-20',
  albumId: p.album,
  width: p.w,
  height: p.h,
}));

export const sampleAlbums: Album[] = [
  { id: 'nature', name: 'Nature', cover: `https://picsum.photos/seed/nature1/300/300`, count: 7, date: '2026-04-20' },
  { id: 'city', name: 'City', cover: `https://picsum.photos/seed/city1/300/300`, count: 4, date: '2026-04-19' },
  { id: 'food', name: 'Food', cover: `https://picsum.photos/seed/food1/300/300`, count: 4, date: '2026-04-18' },
  { id: 'people', name: 'People', cover: `https://picsum.photos/seed/portrait1/300/300`, count: 2, date: '2026-04-17' },
  { id: 'travel', name: 'Travel', cover: `https://picsum.photos/seed/travel1/300/300`, count: 4, date: '2026-04-16' },
  { id: 'pets', name: 'Pets', cover: `https://picsum.photos/seed/pet1/300/300`, count: 2, date: '2026-04-15' },
];

export const backgroundOptions = [
  { id: 'solid-white', type: 'solid' as const, color: '#ffffff', name: 'White' },
  { id: 'solid-black', type: 'solid' as const, color: '#000000', name: 'Black' },
  { id: 'solid-red', type: 'solid' as const, color: '#ef4444', name: 'Red' },
  { id: 'solid-blue', type: 'solid' as const, color: '#3b82f6', name: 'Blue' },
  { id: 'solid-green', type: 'solid' as const, color: '#22c55e', name: 'Green' },
  { id: 'solid-yellow', type: 'solid' as const, color: '#eab308', name: 'Yellow' },
  { id: 'solid-purple', type: 'solid' as const, color: '#a855f7', name: 'Purple' },
  { id: 'solid-pink', type: 'solid' as const, color: '#ec4899', name: 'Pink' },
  { id: 'grad-sunset', type: 'gradient' as const, color: 'linear-gradient(135deg, #f97316, #ec4899)', name: 'Sunset' },
  { id: 'grad-ocean', type: 'gradient' as const, color: 'linear-gradient(135deg, #06b6d4, #3b82f6)', name: 'Ocean' },
  { id: 'grad-forest', type: 'gradient' as const, color: 'linear-gradient(135deg, #22c55e, #065f46)', name: 'Forest' },
  { id: 'grad-night', type: 'gradient' as const, color: 'linear-gradient(135deg, #1e1b4b, #4338ca)', name: 'Night' },
  { id: 'grad-rose', type: 'gradient' as const, color: 'linear-gradient(135deg, #f43f5e, #f97316)', name: 'Rose' },
  { id: 'grad-gold', type: 'gradient' as const, color: 'linear-gradient(135deg, #f59e0b, #d97706)', name: 'Gold' },
  { id: 'grad-mint', type: 'gradient' as const, color: 'linear-gradient(135deg, #6ee7b7, #3b82f6)', name: 'Mint' },
];

export const filterOptions = [
  { id: 'none', name: 'Original', css: '' },
  { id: 'grayscale', name: 'B&W', css: 'grayscale(100%)' },
  { id: 'sepia', name: 'Sepia', css: 'sepia(100%)' },
  { id: 'vintage', name: 'Vintage', css: 'sepia(50%) contrast(90%) brightness(95%)' },
  { id: 'warm', name: 'Warm', css: 'saturate(150%) brightness(105%)' },
  { id: 'cool', name: 'Cool', css: 'saturate(80%) hue-rotate(20deg) brightness(105%)' },
  { id: 'dramatic', name: 'Dramatic', css: 'contrast(140%) brightness(90%) saturate(120%)' },
  { id: 'fade', name: 'Fade', css: 'contrast(85%) brightness(115%) saturate(80%)' },
  { id: 'vivid', name: 'Vivid', css: 'saturate(200%) contrast(110%)' },
  { id: 'noir', name: 'Noir', css: 'grayscale(100%) contrast(150%) brightness(90%)' },
  { id: 'bright', name: 'Bright', css: 'brightness(130%) contrast(95%)' },
  { id: 'moody', name: 'Moody', css: 'contrast(120%) brightness(85%) saturate(130%)' },
];

export const fontOptions = [
  { id: 'sans', name: 'Sans Serif', family: 'system-ui, sans-serif' },
  { id: 'serif', name: 'Serif', family: 'Georgia, serif' },
  { id: 'mono', name: 'Mono', family: 'monospace' },
  { id: 'cursive', name: 'Cursive', family: 'cursive' },
];
