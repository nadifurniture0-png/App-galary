'use client'

import { useGalleryStore } from '@/lib/gallery-store'

const solidColors = [
  '#000000',
  '#1a1a2e',
  '#16213e',
  '#0f3460',
  '#533483',
  '#e94560',
  '#f59e0b',
  '#22c55e',
  '#ffffff',
  '#374151',
]

const gradients = [
  { name: 'Sunset', colors: '#f97316, #ec4899' },
  { name: 'Ocean', colors: '#06b6d4, #3b82f6' },
  { name: 'Forest', colors: '#22c55e, #065f46' },
  { name: 'Dusk', colors: '#7c3aed, #db2777' },
  { name: 'Warm', colors: '#f59e0b, #ef4444' },
  { name: 'Night', colors: '#1e1b4b, #312e81' },
  { name: 'Candy', colors: '#f472b6, #a78bfa' },
  { name: 'Emerald', colors: '#10b981, #059669' },
]

const blendModes = [
  'normal',
  'multiply',
  'screen',
  'overlay',
  'darken',
  'lighten',
  'color-dodge',
  'color-burn',
]

export function BackgroundTool() {
  const { backgroundColor, backgroundGradient, backgroundBlend, setBackgroundColor, setBackgroundGradient, setBackgroundBlend } =
    useGalleryStore()

  return (
    <div className="px-4 py-3 space-y-3">
      {/* Solid Colors */}
      <div>
        <p className="text-xs text-white/40 mb-2">Solid Colors</p>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            className={`w-8 h-8 rounded-lg border-2 transition-transform active:scale-90 ${
              backgroundColor === 'transparent' && !backgroundGradient ? 'border-amber-400' : 'border-transparent'
            }`}
            style={{
              background: 'repeating-conic-gradient(#333 0% 25%, #555 0% 50%) 50% / 8px 8px',
            }}
            onClick={() => {
              setBackgroundColor('transparent')
              setBackgroundGradient(null)
            }}
            aria-label="Transparent background"
          />
          {solidColors.map((color) => (
            <button
              key={color}
              className={`w-8 h-8 rounded-lg border-2 transition-transform active:scale-90 ${
                backgroundColor === color && !backgroundGradient ? 'border-amber-400' : 'border-transparent'
              }`}
              style={{ backgroundColor: color }}
              onClick={() => {
                setBackgroundColor(color)
                setBackgroundGradient(null)
              }}
              aria-label={`Background ${color}`}
            />
          ))}
          <input
            type="color"
            value={backgroundColor === 'transparent' ? '#000000' : backgroundColor}
            onChange={(e) => {
              setBackgroundColor(e.target.value)
              setBackgroundGradient(null)
            }}
            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
            aria-label="Custom background color"
          />
        </div>
      </div>

      {/* Gradients */}
      <div>
        <p className="text-xs text-white/40 mb-2">Gradients</p>
        <div className="flex items-center gap-2 flex-wrap">
          {gradients.map((grad) => (
            <button
              key={grad.name}
              className={`w-10 h-10 rounded-lg border-2 transition-transform active:scale-90 ${
                backgroundGradient === grad.colors ? 'border-amber-400' : 'border-transparent'
              }`}
              style={{
                background: `linear-gradient(135deg, ${grad.colors})`,
              }}
              onClick={() => {
                setBackgroundGradient(grad.colors)
                setBackgroundColor('transparent')
              }}
              aria-label={`${grad.name} gradient`}
            />
          ))}
        </div>
      </div>

      {/* Blend Modes */}
      <div>
        <p className="text-xs text-white/40 mb-2">Blend Mode</p>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {blendModes.map((mode) => (
            <button
              key={mode}
              className={`flex-shrink-0 px-2.5 py-1.5 rounded-md text-[10px] font-medium transition-colors ${
                backgroundBlend === mode
                  ? 'bg-amber-400/20 text-amber-400'
                  : 'bg-white/5 text-white/50'
              }`}
              onClick={() => setBackgroundBlend(mode)}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
