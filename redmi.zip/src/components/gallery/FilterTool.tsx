'use client'

import { useGalleryStore, type FilterType } from '@/lib/gallery-store'

const filters: { id: FilterType; label: string; css: string }[] = [
  { id: 'original', label: 'Original', css: 'none' },
  { id: 'grayscale', label: 'Grayscale', css: 'grayscale(100%)' },
  { id: 'sepia', label: 'Sepia', css: 'sepia(100%)' },
  { id: 'bright', label: 'Bright', css: 'brightness(1.4)' },
  { id: 'contrast', label: 'Contrast', css: 'contrast(1.5)' },
  { id: 'vintage', label: 'Vintage', css: 'sepia(40%) contrast(1.1) brightness(0.9)' },
  { id: 'warm', label: 'Warm', css: 'sepia(20%) saturate(1.3) brightness(1.05)' },
  { id: 'cool', label: 'Cool', css: 'saturate(0.8) brightness(1.05) hue-rotate(15deg)' },
]

const filterThumbnails: Record<FilterType, string> = {
  original: '/gallery/mountain.jpg',
  grayscale: '/gallery/mountain.jpg',
  sepia: '/gallery/mountain.jpg',
  bright: '/gallery/mountain.jpg',
  contrast: '/gallery/mountain.jpg',
  vintage: '/gallery/mountain.jpg',
  warm: '/gallery/mountain.jpg',
  cool: '/gallery/mountain.jpg',
}

export function FilterTool() {
  const { activeFilter, setActiveFilter } = useGalleryStore()

  return (
    <div className="px-4 py-3">
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
        {filters.map((filter) => (
          <button
            key={filter.id}
            className={`flex-shrink-0 flex flex-col items-center gap-1.5 transition-transform active:scale-95 ${
              activeFilter === filter.id ? 'scale-105' : ''
            }`}
            onClick={() => setActiveFilter(filter.id)}
            aria-label={`Apply ${filter.label} filter`}
          >
            <div
              className={`w-14 h-14 rounded-lg overflow-hidden border-2 ${
                activeFilter === filter.id ? 'border-amber-400' : 'border-transparent'
              }`}
            >
              <img
                src={filterThumbnails[filter.id]}
                alt={filter.label}
                className="w-full h-full object-cover"
                style={{ filter: filter.css }}
              />
            </div>
            <span
              className={`text-[10px] font-medium ${
                activeFilter === filter.id ? 'text-amber-400' : 'text-white/50'
              }`}
            >
              {filter.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  )
}
