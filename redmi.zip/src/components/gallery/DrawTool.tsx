'use client'

import { useGalleryStore } from '@/lib/gallery-store'
import { Eraser } from 'lucide-react'

const presetColors = [
  '#ffffff',
  '#000000',
  '#f59e0b',
  '#ef4444',
  '#22c55e',
  '#3b82f6',
  '#a855f7',
  '#ec4899',
  '#06b6d4',
  '#f97316',
]

export function DrawTool() {
  const { drawColor, drawSize, isEraser, setDrawColor, setDrawSize, setIsEraser } =
    useGalleryStore()

  return (
    <div className="px-4 py-3 space-y-3">
      {/* Brush Size */}
      <div className="flex items-center gap-3">
        <span className="text-xs text-white/50 w-8">{drawSize}px</span>
        <input
          type="range"
          min="1"
          max="30"
          value={drawSize}
          onChange={(e) => setDrawSize(Number(e.target.value))}
          className="flex-1 accent-amber-400 h-1"
        />
        <div
          className="rounded-full flex-shrink-0"
          style={{
            width: Math.max(4, drawSize) + 'px',
            height: Math.max(4, drawSize) + 'px',
            backgroundColor: isEraser ? '#666' : drawColor,
          }}
        />
      </div>

      {/* Eraser Toggle */}
      <div className="flex items-center gap-2">
        <button
          className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
            isEraser ? 'bg-amber-400/20 text-amber-400' : 'bg-white/5 text-white/50'
          }`}
          onClick={() => setIsEraser(!isEraser)}
          aria-label="Eraser mode"
        >
          <Eraser className="w-4 h-4" />
          Eraser {isEraser ? 'On' : 'Off'}
        </button>
      </div>

      {/* Color Picker */}
      <div className="flex items-center gap-2 flex-wrap">
        {presetColors.map((color) => (
          <button
            key={color}
            className={`w-7 h-7 rounded-full border-2 transition-transform active:scale-90 ${
              drawColor === color && !isEraser ? 'border-amber-400 scale-110' : 'border-transparent'
            }`}
            style={{ backgroundColor: color }}
            onClick={() => {
              setDrawColor(color)
              setIsEraser(false)
            }}
            aria-label={`Brush color ${color}`}
          />
        ))}
        <input
          type="color"
          value={drawColor}
          onChange={(e) => {
            setDrawColor(e.target.value)
            setIsEraser(false)
          }}
          className="w-7 h-7 rounded-full cursor-pointer border-0 bg-transparent"
          aria-label="Custom brush color"
        />
      </div>
    </div>
  )
}
