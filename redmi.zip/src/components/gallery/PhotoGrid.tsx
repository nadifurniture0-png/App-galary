'use client'

import { type Photo } from '@/lib/gallery-store'
import { format, parseISO } from 'date-fns'
import { Heart } from 'lucide-react'

interface PhotoGridProps {
  photos: Photo[]
  onPhotoClick: (index: number) => void
}

function groupByDate(photos: Photo[]): Record<string, Photo[]> {
  const groups: Record<string, Photo[]> = {}
  for (const photo of photos) {
    const dateKey = photo.date
    if (!groups[dateKey]) groups[dateKey] = []
    groups[dateKey].push(photo)
  }
  return groups
}

function formatDateLabel(dateStr: string): string {
  try {
    const date = parseISO(dateStr)
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (format(date, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')) return 'Today'
    if (format(date, 'yyyy-MM-dd') === format(yesterday, 'yyyy-MM-dd')) return 'Yesterday'
    return format(date, 'MMMM d, yyyy')
  } catch {
    return dateStr
  }
}

export function PhotoGrid({ photos, onPhotoClick }: PhotoGridProps) {
  const grouped = groupByDate(photos)
  const sortedDates = Object.keys(grouped).sort((a, b) => b.localeCompare(a))

  if (photos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-white/30 gap-3">
        <svg className="w-16 h-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1}
            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
          />
        </svg>
        <p className="text-sm">No photos yet</p>
      </div>
    )
  }

  return (
    <div className="pb-4">
      {sortedDates.map((date) => (
        <div key={date} className="mb-2">
          <div className="px-4 py-2 sticky top-0 bg-[#0a0a0a]/90 backdrop-blur-sm z-10">
            <h3 className="text-sm font-semibold text-white/70">{formatDateLabel(date)}</h3>
          </div>
          <div className="grid grid-cols-3 gap-0.5 px-0.5">
            {grouped[date].map((photo) => {
              const globalIndex = photos.findIndex((p) => p.id === photo.id)
              return (
                <button
                  key={photo.id}
                  className="aspect-square relative overflow-hidden active:opacity-80 transition-opacity"
                  onClick={() => onPhotoClick(globalIndex)}
                  aria-label={`View ${photo.title}`}
                >
                  <img
                    src={photo.src}
                    alt={photo.title}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  {photo.isFavorite && (
                    <div className="absolute top-1.5 right-1.5">
                      <Heart className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    </div>
                  )}
                </button>
              )
            })}
          </div>
        </div>
      ))}
    </div>
  )
}
