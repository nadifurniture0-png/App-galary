'use client';

import React, { useState } from 'react';
import { Album } from './types';

interface AlbumViewProps {
  albums: Album[];
  onAlbumClick: (albumId: string) => void;
  onBack: () => void;
  onCreateAlbum: (name: string) => void;
}

export default function AlbumView({ albums, onAlbumClick, onBack, onCreateAlbum }: AlbumViewProps) {
  const [showCreate, setShowCreate] = useState(false);
  const [newAlbumName, setNewAlbumName] = useState('');

  const handleCreate = () => {
    if (newAlbumName.trim()) {
      onCreateAlbum(newAlbumName.trim());
      setNewAlbumName('');
      setShowCreate(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-zinc-900/95 backdrop-blur-sm border-b border-zinc-800">
        <button onClick={onBack} className="flex items-center gap-1 text-white hover:text-amber-400 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
          <span className="text-sm">Back</span>
        </button>
        <h2 className="text-white font-semibold text-lg">Albums</h2>
        <button
          onClick={() => setShowCreate(!showCreate)}
          className="text-amber-400 hover:text-amber-300 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14"/></svg>
        </button>
      </div>

      {/* Create Album Input */}
      {showCreate && (
        <div className="px-4 py-3 bg-zinc-800/80 border-b border-zinc-700 flex gap-2">
          <input
            value={newAlbumName}
            onChange={(e) => setNewAlbumName(e.target.value)}
            placeholder="Album name..."
            className="flex-1 bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm border border-zinc-600 focus:border-amber-400 focus:outline-none"
            autoFocus
            onKeyDown={(e) => { if (e.key === 'Enter') handleCreate(); }}
          />
          <button
            onClick={handleCreate}
            className="bg-amber-500 text-black font-semibold px-4 py-2 rounded-lg text-sm hover:bg-amber-600 transition-colors"
          >
            Create
          </button>
        </div>
      )}

      {/* Albums Grid */}
      <div className="flex-1 overflow-y-auto p-3 scrollbar-hide">
        <div className="grid grid-cols-2 gap-3">
          {albums.map(album => (
            <button
              key={album.id}
              onClick={() => onAlbumClick(album.id)}
              className="group relative overflow-hidden rounded-xl bg-zinc-800 border border-zinc-700 hover:border-amber-400/50 transition-all active:scale-95"
            >
              <div className="aspect-square overflow-hidden">
                <img
                  src={album.cover}
                  alt={album.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-3">
                <h3 className="text-white font-semibold text-sm truncate">{album.name}</h3>
                <p className="text-zinc-400 text-xs">{album.count} photos</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
