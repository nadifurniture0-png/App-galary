'use client'

import type { EditorTool } from '@/lib/gallery-store'
import { Crop, Paintbrush, Type, Sparkles, Image as ImageIcon } from 'lucide-react'

interface EditorToolbarProps {
  activeTool: EditorTool
  onToolChange: (tool: EditorTool) => void
}

const tools: { id: EditorTool; icon: React.ReactNode; label: string }[] = [
  { id: 'crop', icon: <Crop className="w-5 h-5" />, label: 'Crop' },
  { id: 'filter', icon: <Sparkles className="w-5 h-5" />, label: 'Filter' },
  { id: 'text', icon: <Type className="w-5 h-5" />, label: 'Text' },
  { id: 'draw', icon: <Paintbrush className="w-5 h-5" />, label: 'Draw' },
  { id: 'background', icon: <ImageIcon className="w-5 h-5" />, label: 'Bg' },
]

export function EditorToolbar({ activeTool, onToolChange }: EditorToolbarProps) {
  return (
    <div className="flex items-center justify-around px-2 py-2 border-t border-white/5">
      {tools.map((tool) => (
        <button
          key={tool.id}
          className={`flex flex-col items-center gap-0.5 px-3 py-2 rounded-lg transition-colors min-w-[52px] ${
            activeTool === tool.id
              ? 'text-amber-400 bg-amber-400/10'
              : 'text-white/50 active:bg-white/5'
          }`}
          onClick={() => onToolChange(activeTool === tool.id ? 'none' : tool.id)}
          aria-label={tool.label}
        >
          {tool.icon}
          <span className="text-[9px] font-medium">{tool.label}</span>
        </button>
      ))}
    </div>
  )
}
