'use client'

import GalleryApp from '@/components/gallery/GalleryApp'

export default function Home() {
  return (
    <main className="h-screen w-screen overflow-hidden">
      <GalleryApp />
    </main>
  )
}
